import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-tabset-page',
  templateUrl: './tabset-page.component.html',
  styleUrls: ['./tabset-page.component.css']
})
export class TabsetPageComponent implements OnInit {

  public isAddEducation = false;
  public isAddExperience = false;

  constructor() { }

  ngOnInit(): void {
  }

}
