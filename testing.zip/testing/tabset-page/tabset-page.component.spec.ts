import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TabsetPageComponent } from './tabset-page.component';

describe('TabsetPageComponent', () => {
  let component: TabsetPageComponent;
  let fixture: ComponentFixture<TabsetPageComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TabsetPageComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TabsetPageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
