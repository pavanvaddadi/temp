import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TestAddEmployeeComponent } from './test-add-employee.component';

describe('TestAddEmployeeComponent', () => {
  let component: TestAddEmployeeComponent;
  let fixture: ComponentFixture<TestAddEmployeeComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TestAddEmployeeComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TestAddEmployeeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
