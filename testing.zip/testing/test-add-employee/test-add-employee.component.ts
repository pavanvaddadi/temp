import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-test-add-employee',
  templateUrl: './test-add-employee.component.html',
  styleUrls: ['./test-add-employee.component.css']
})
export class TestAddEmployeeComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
