import {Component, OnInit, ViewChild} from '@angular/core';
import {ModalDirective} from "ngx-bootstrap/modal";

@Component({
  selector: 'app-test-department',
  templateUrl: './test-department.component.html',
  styleUrls: ['./test-department.component.css']
})
export class TestDepartmentComponent implements OnInit {

  @ViewChild('departmentModal') public departmentModal: ModalDirective;
  @ViewChild('conformationAlert') public conformationAlert: ModalDirective;

  constructor() { }

  ngOnInit(): void {
  }

  public showDeptModal() {
    this.departmentModal.show();
  }

  public hideDeptModal() {
    this.departmentModal.hide();
  }

  public departmentConformationAlert() {
    this.conformationAlert.show();
  }
}
