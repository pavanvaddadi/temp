import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-experience',
  templateUrl: './add-experience.component.html',
  styleUrls: ['./add-experience.component.css', '../test-add-employee/test-add-employee.component.css']
})
export class AddExperienceComponent implements OnInit {
  public isAddMore = false;

  constructor() { }

  ngOnInit(): void {
  }

}
