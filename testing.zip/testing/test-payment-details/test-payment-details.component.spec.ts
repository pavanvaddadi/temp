import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TestPaymentDetailsComponent } from './test-payment-details.component';

describe('TestPaymentDetailsComponent', () => {
  let component: TestPaymentDetailsComponent;
  let fixture: ComponentFixture<TestPaymentDetailsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TestPaymentDetailsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TestPaymentDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
