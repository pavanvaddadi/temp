import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-test-payment-details',
  templateUrl: './test-payment-details.component.html',
  styleUrls: ['./test-payment-details.component.css', '../test-add-employee/test-add-employee.component.css']
})
export class TestPaymentDetailsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
