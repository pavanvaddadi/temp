import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-education-details',
  templateUrl: './add-education-details.component.html',
  styleUrls: ['./add-education-details.component.css', '../test-add-employee/test-add-employee.component.css']
})
export class AddEducationDetailsComponent implements OnInit {

  public isAddMore = false;

  constructor() { }

  ngOnInit(): void {
  }

}
