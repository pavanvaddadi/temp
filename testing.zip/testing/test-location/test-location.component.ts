import {Component, OnInit, ViewChild} from '@angular/core';
import {ModalDirective} from "ngx-bootstrap/modal";

@Component({
  selector: 'app-test-location',
  templateUrl: './test-location.component.html',
  styleUrls: ['./test-location.component.css']
})
export class TestLocationComponent implements OnInit {

  @ViewChild('locationModal') public locationModal: ModalDirective;
  @ViewChild('conformationAlert') public conformationAlert: ModalDirective;


  constructor() { }

  ngOnInit(): void {
  }

  public showLocationModal() {
    this.locationModal.show();
  }

  public hideLocationModal() {
    this.locationModal.hide();
  }

  public locationConformationAlert() {
    this.conformationAlert.show();
  }

}
