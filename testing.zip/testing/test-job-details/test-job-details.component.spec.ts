import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TestJobDetailsComponent } from './test-job-details.component';

describe('TestJobDetailsComponent', () => {
  let component: TestJobDetailsComponent;
  let fixture: ComponentFixture<TestJobDetailsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TestJobDetailsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TestJobDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
