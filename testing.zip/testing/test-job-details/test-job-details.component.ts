import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-test-job-details',
  templateUrl: './test-job-details.component.html',
  styleUrls: ['./test-job-details.component.css', '../test-add-employee/test-add-employee.component.css']
})
export class TestJobDetailsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
