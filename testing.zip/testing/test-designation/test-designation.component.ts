import {Component, OnInit, ViewChild} from '@angular/core';
import {ModalDirective} from "ngx-bootstrap/modal";

@Component({
  selector: 'app-test-designation',
  templateUrl: './test-designation.component.html',
  styleUrls: ['./test-designation.component.css']
})
export class TestDesignationComponent implements OnInit {


  @ViewChild('designationModal') public designationModal: ModalDirective;
  @ViewChild('conformationAlert') public conformationAlert: ModalDirective;


  constructor() { }

  ngOnInit(): void {
  }


  public showDesignationModal() {
    this.designationModal.show();
  }

  public hideDesignationModal() {
    this.designationModal.hide();
  }

  public designationConformationAlert() {
    this.conformationAlert.show();
  }
}
