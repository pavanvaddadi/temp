import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TestDesignationComponent } from './test-designation.component';

describe('TestDesignationComponent', () => {
  let component: TestDesignationComponent;
  let fixture: ComponentFixture<TestDesignationComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TestDesignationComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TestDesignationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
