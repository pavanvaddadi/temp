import { ChangeDetectorRef, Component, OnInit } from '@angular/core';
import { PlatformApiService, SysManService } from '../../core/_services';
import { HttpClient } from '@angular/common/http';
import { ActivatedRoute, Router } from '@angular/router';
import { environment } from '../../../environments/environment';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-test-table',
  templateUrl: './test-table.component.html',
  styleUrls: ['./test-table.component.css']
})
export class TestTableComponent implements OnInit {

    private _subSearchEmployeesData: Subscription;
    private _currentPage: number = 13;
    private _totalItems: number = 122;
    private _offset: number = 120;

    private _queryResultHandle: number;
    private _employeesData: Array<Object> = [{}];

    get currentPage(): number {
        return this._currentPage;
    }

    set currentPage(value: number) {
        this._currentPage = value;
    }

    get totalItems(): number {
        return this._totalItems;
    }

    set totalItems(value: number) {
        this._totalItems = value;
    }

    get offset(): number {
        return this._offset;
    }

    set offset(value: number) {
        this._offset = value;
    }

    get employeesData(): Array<Object> {
        return this._employeesData;
    }

    set employeesData(value: Array<Object>) {
        this._employeesData = value;
    }


    get queryResultHandle(): number {
        return this._queryResultHandle;
    }

    set queryResultHandle(value: number) {
        this._queryResultHandle = value;
    }

    constructor(private _sysMan: SysManService,
                private _platformService: PlatformApiService,
                private _cdr: ChangeDetectorRef,
                private _httpClient: HttpClient,
                private _router: Router,
                private _activatedRoute: ActivatedRoute) {
    }

    ngOnInit(): void {
        this.searchEmployeesData();
    }

    public searchEmployeesData() {
        this._sysMan.logger.debug('START _generateAccessToken()', this.constructor.name);
        let queryUrl = environment.apiUrl + '/testing/testing?type=query';
        //  let queryUrl = environment.platformApiUrl + '/testing/testing' + '?offset=' + this.offset;
        this._subSearchEmployeesData = this._platformService.get(queryUrl).subscribe(
            (response) => {
                this.queryResultHandle = response.results[0]['resultHandle'];
                setTimeout (() => {
                    this._getQueryResult();
                }, 3000);
            });
        this._sysMan.logger.debug('END _generateAccessToken()', this.constructor.name);
    }

    public onPageChange(currentPage: number): void {
        this._sysMan.logger.debug('START onPageChange()', this.constructor.name);
        this.currentPage = currentPage;
        this.offset = (this.currentPage - 1) * 10 + 1;
        // this.searchEmployeesData();
        this._getQueryResult();
        this._sysMan.logger.debug('END onPageChange()', this.constructor.name);
    }

    private _getQueryResult() {
        this._sysMan.logger.debug('START _getQueryResult()', this.constructor.name);
        let resultUrl = environment.apiUrl + '/testing/testing?type=result' + '&offset=' + this.offset + '&resultHandle=' + this.queryResultHandle;
        this._subSearchEmployeesData = this._platformService.get(resultUrl).subscribe(
            (response) => {
                this.employeesData = response.results;
            });
        this._sysMan.logger.debug('END _getQueryResult()', this.constructor.name);
    }
}

