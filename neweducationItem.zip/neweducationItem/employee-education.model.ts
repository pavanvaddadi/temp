import { Injectable } from '@angular/core';
import { ModelAbstract } from '../../shared/_abstracts/model';
import { SysManService } from '../../core/_services';
import { EmployeeEducationMapperService } from './employee-education-mapper.service';
import {catchError, map} from "rxjs/operators";
import {Observable, of, throwError} from "rxjs";
import {AustinHrApiResponse} from "../../core/_services/austin-hr-api-response-type";

@Injectable()
export class EmployeeEducationModel extends ModelAbstract {

    // region Private properties. Becomes public with getter and setters
    private _id: number;
    private _idEmployee: number;
    private _level: string;
    private _stream: string;
    private _institute: string;
    private _passedYear: Date;
    private _finalScore: string;
    private _finalScoreIn: string;
    private _courseType: string;
    private _createdDate: Date;
    private _modifiedDate: Date;
    private _createdBy: number;
    private _modifiedBy: number;
    // endregion

    // region GETTERS/SETTERS for all private properties to make them public
    get id(): number {
        return this._id;
    }

    set id(value: number) {
        this._id = value;
    }

    get idEmployee(): number {
        return this._idEmployee;
    }

    set idEmployee(value: number) {
        this._idEmployee = value;
    }

    get level(): string {
        return this._level;
    }

    set level(value: string) {
        this._level = value;
    }

    get stream(): string {
        return this._stream;
    }

    set stream(value: string) {
        this._stream = value;
    }

    get institute(): string {
        return this._institute;
    }

    set institute(value: string) {
        this._institute = value;
    }

    get passedYear(): Date {
        return this._passedYear;
    }

    set passedYear(value: Date) {
        this._passedYear = value;
    }

    get finalScore(): string {
        return this._finalScore;
    }

    set finalScore(value: string) {
        this._finalScore = value;
    }

    get finalScoreIn(): string {
        return this._finalScoreIn;
    }

    set finalScoreIn(value: string) {
        this._finalScoreIn = value;
    }

    get courseType(): string {
        return this._courseType;
    }

    set courseType(value: string) {
        this._courseType = value;
    }

    get createdDate(): Date {
        return this._createdDate;
    }

    set createdDate(value: Date) {
        this._createdDate = value;
    }

    get modifiedDate(): Date {
        return this._modifiedDate;
    }

    set modifiedDate(value: Date) {
        this._modifiedDate = value;
    }

    get createdBy(): number {
        return this._createdBy;
    }

    set createdBy(value: number) {
        this._createdBy = value;
    }

    get modifiedBy(): number {
        return this._modifiedBy;
    }

    set modifiedBy(value: number) {
        this._modifiedBy = value;
    }

    // endregion

    /**
     * Constructor method for EmployeeEducationModel
     * @param _sysMan   SysManService                      Dependency Injection for SysManService
     * @param _mapper   EmployeeEducationMapperService      Dependency Injection for EmployeeEducationMapperService
     */
    constructor(protected _sysMan: SysManService, protected _mapper: EmployeeEducationMapperService) {
        super(_sysMan, _mapper);
    }

    public update(updateProps: {} | Array<{}> = null): Observable<this | this[] | boolean | {results: {}[]}> {
        this._sysMan.logger.debug('Start EmployeeEducationModel->update()', this.constructor.name);
        console.log(updateProps);
            return this._mapper.put(updateProps).pipe (
                map(
                    (resp: AustinHrApiResponse) => {
                        if (resp != null) {
                            let models = this.setFromArray(resp.models);
                            this._sysMan.logger.debug('End EmployeeEducationModel->update()', this.constructor.name);
                            return models;
                        }
                    }
                ),
                catchError(
                    error => this.errorHandler('update', error)
                )
            );
        }
}
