import { Component, Input, OnDestroy, OnInit } from '@angular/core';
import { SysManService } from '../../core/_services';
import { EmployeeEducationModel } from '../_models';
import { EmployeeFeatureEnum } from '../../shared/utilities/enums/common.enum';
import {Subscription} from "rxjs";

@Component({
    selector: 'employee-education',
    templateUrl: './employee-education.component.html',
    styleUrls: ['./employee-education.component.css', '../employee-state.component.css'],
    providers: [EmployeeEducationModel]
})
export class EmployeeEducationComponent implements OnInit, OnDestroy {

    // region class constants
    public readonly MODE_TYPE = {'VIEW': 'view', 'ADD': 'add', 'EDIT': 'edit'};
    public readonly CURRENT_MODULE = 'employee';
    public readonly FEATURE_TYPE = EmployeeFeatureEnum;
    public readonly DEFAULT_ROW_COUNT = 3;
    // endregion

    // region Private properties to hold INPUT property received
    private _selectedEmployeeId: number;
    private _educationList: Array<EmployeeEducationModel>;
    // endregion

    // region Private properties. Becomes public with getter and setters
    private _newEducationInstance: Array<EmployeeEducationModel>;       // property to hold the new educational instances
    private _mode: string;
    private _isSaveSuccess: boolean = false;
    private _isSaveError: boolean = false;
    private _message: string;
    private _isValidateEducationItem: boolean = false;                  // property to hold the each education Item is valid or not
    private _isValidEducationForm: boolean = true;                     // property to check whether the education form is valid or not
    private _isShowForm: boolean = false;                             // property to check whether the education form is valid or not
    private _isShowLoader: boolean = false;                   // property used to show the loader
    // endregion

    // region private properties required for internal logic. No GETTER/SETTERS required
    private _subEmployeeEducationCreate: Subscription;
    // endregion

    // region GETTERS/SETTERS for all input properties
    get selectedEmployeeId(): number {
        return this._selectedEmployeeId;
    }

    @Input() set selectedEmployeeId(value: number) {
        this._selectedEmployeeId = value;
    }

    get educationList(): Array<EmployeeEducationModel> {
        return this._educationList;
    }

    @Input() set educationList(value: Array<EmployeeEducationModel>) {
        this._educationList = value;
    }

// endregion

    // region GETTERS/SETTERS for all public properties


    get newEducationInstance(): Array<EmployeeEducationModel> {
        return this._newEducationInstance;
    }

    set newEducationInstance(value: Array<EmployeeEducationModel>) {
        this._newEducationInstance = value;
    }


    get mode(): string {
        return this._mode;
    }

    set mode(value: string) {
        this._mode = value;
    }

    get isSaveSuccess(): boolean {
        return this._isSaveSuccess;
    }

    set isSaveSuccess(value: boolean) {
        this._isSaveSuccess = value;
        if (this._isSaveSuccess == true) {
            setTimeout(() => {
                this.isSaveSuccess = false;
            }, 2000);
        }
    }

    get isSaveError(): boolean {
        return this._isSaveError;
    }

    set isSaveError(value: boolean) {
        this._isSaveError = value;
    }

    get message(): string {
        return this._message;
    }

    set message(value: string) {
        this._message = value;
    }

    get isValidateEducationItem(): boolean {
        return this._isValidateEducationItem;
    }

    set isValidateEducationItem(value: boolean) {
        this._isValidateEducationItem = value;
    }

    get isValidEducationForm(): boolean {
        return this._isValidEducationForm;
    }

    set isValidEducationForm(value: boolean) {
        this._isValidEducationForm = value;
    }


    get isShowForm(): boolean {
        return this._isShowForm;
    }

    set isShowForm(value: boolean) {
        this._isShowForm = value;
    }

    get isShowLoader(): boolean {
        return this._isShowLoader;
    }

    set isShowLoader(value: boolean) {
        this._isShowLoader = value;
    }

// endregion

    /**
     * Constructor method for EmployeeEducationComponent
     * @param  _sysMan                 SysManService           Dependency injection for SysManService
     * @param _educationModel         EmployeeEducationModel   Dependency injection for EmployeeEducationModel
     */
    constructor(private _sysMan: SysManService,
                private _educationModel: EmployeeEducationModel) {
        this._sysMan.logger.debug('START constructor()', this.constructor.name);
        this._sysMan.logger.debug('END constructor()', this.constructor.name);
    }

    /**
     *  Lifecycle hook called after construction for initialization tasks
     */
    ngOnInit(): void {
        this._sysMan.logger.debug('START ngOnInit()', this.constructor.name);
        if (this.educationList && this.educationList.length == 0) {
            this.changeModeTo(this.MODE_TYPE.ADD, this.DEFAULT_ROW_COUNT);
        }
        this._sysMan.logger.debug('END ngOnInit()', this.constructor.name);
    }


    /**
     * Lifecycle hook called before destruction of Component. During this time, the following occurs:
     * Unsubscribe to all active subscriptions (if any), in order to guard against memory leaks.
     */
    ngOnDestroy() {
        this._sysMan.logger.debug('START ngOnDestroy()', this.constructor.name);
        if (this._subEmployeeEducationCreate) {
            this._subEmployeeEducationCreate.unsubscribe();
        }
        this._sysMan.logger.debug('END ngOnDestroy()', this.constructor.name);
    }

    /**
     * call the method when action types are changed
     */
    public changeModeTo(mode, count: number = null) {
        this._sysMan.logger.debug('START changeActionTo()', this.constructor.name);
        if (mode == this.MODE_TYPE.ADD) {
            this.newEducationInstance =  this.newEducationInstance?.length > 0 ? this.newEducationInstance : [];
            if (count != this.DEFAULT_ROW_COUNT) {
                this.newEducationInstance.push(this._educationModel.getInstance(this._educationModel));
            } else {
                for (let i = 0; i < count; i++) {
                    this.newEducationInstance.push(this._educationModel.getInstance(this._educationModel));
                }
            }
            this.isShowForm = true;
        }
        this.mode = mode;
        this._sysMan.logger.debug('END changeActionTo()', this.constructor.name);
    }

    /**
     * method used to save the education Records.
     * Proxy to create method
     */
    public onEducationSave(isValidateForm) {
        this._sysMan.logger.debug('START createEmployeeEducation()', this.constructor.name);
        // if the user clicks on save button then it will send true value to educationItem component to check if the educationForm is valid or not
        this.isValidateEducationItem = isValidateForm;
        // Check if all the educationItem form fields are valid then
        if (this.isValidEducationForm == true) {
            this.isShowLoader = true;
                this._subEmployeeEducationCreate =this._educationModel.update(this.newEducationInstance).subscribe(
                    (resp) => {
                        this.isShowLoader = false;
                        resp = resp as EmployeeEducationModel[];
                        resp = Array.isArray(resp) ? resp : [resp];
                       this.educationList = this.educationList && this.educationList.length  > 0 ? this.educationList : [];
                        let savedItems = resp.filter((eachItem) => eachItem.error == 0 && (eachItem.messages['INSERT_SUCCESS'] || eachItem.messages['UPDATE_SUCCESS']));
                        if(savedItems.length == this.newEducationInstance.length) {
                            this.message = this.mode == this.MODE_TYPE.EDIT ? savedItems[0].messages['UPDATE_SUCCESS'] as string : savedItems[0].messages['INSERT_SUCCESS'] as string;
                            this.isSaveSuccess = true;
                            this.isShowForm = false;
                            if(this.mode == this.MODE_TYPE.ADD) {
                                this.educationList.push(...savedItems);
                            } else{
                                // do nothing
                            }
                            this.newEducationInstance = [];
                        } else {

                            // need to check error messages.
                           this.message = 'Failed to create the Record';
                           this.isSaveError = true;
                        }
                    }, (error) => {
                        this.isShowLoader = false;
                        this._sysMan.logger.error('Error in createEmployeeEducation()' + JSON.stringify(error), this.constructor.name);
                }, () => {
                    // stop loader
                    // form reset
                    // isShow form false
                });

        } else {
            // do nothing
        }
        this._sysMan.logger.debug('END createEmployeeEducation()', this.constructor.name);
    }


    /**
     *  call the method when education item component emits if the EmployeeEducationForm is valid
     * @param event
     */
    public onEmployeeEducationItemSave(event) {
        this._sysMan.logger.debug('START onEmployeeEducationItemSave()', this.constructor.name);
        // if  EmployeeEducationForm is valid then set 'isValidEducationForm' value to true, so that we can send request to backend
        this.isValidEducationForm = event == true;
        //
        setTimeout(() => {
            this.isValidateEducationItem = false;
        }, 50);
        this._sysMan.logger.debug('END onEmployeeEducationItemSave()', this.constructor.name);

    }

    public onChangeMode(event, index: number) {
        if(event == true) {
            this.newEducationInstance = [];
            this.isShowForm = true;
            this.mode = this.MODE_TYPE.EDIT;
            this.newEducationInstance.push(this.educationList[index]);
        } else {
            this.mode = this.MODE_TYPE.VIEW;
        }
    }


}
