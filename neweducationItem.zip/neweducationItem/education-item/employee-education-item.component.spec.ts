import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EmployeeEducationItemComponent } from './employee-education-item.component';

describe('EmployeeEducationItemComponent', () => {
  let component: EmployeeEducationItemComponent;
  let fixture: ComponentFixture<EmployeeEducationItemComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EmployeeEducationItemComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EmployeeEducationItemComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
