import { Component, EventEmitter, Input, OnDestroy, OnInit, Output } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { Router } from '@angular/router';
import { SysManService } from '../../core/_services';
import { EmployeeEducationModel } from '../_models';

@Component({
    selector: 'employee-education-item',
    templateUrl: './employee-education-item.component.html',
    styleUrls: ['./employee-education-item.component.css', '../employee-state.component.css'],
    providers: [EmployeeEducationModel]
})
export class EmployeeEducationItemComponent implements OnInit {

    // region class constants
    public readonly SCORE_TYPE: { key: string, text: string }[] = [
        {key: 'percentage', text: '%'},
        {key: 'cgpa', text: 'CGPA'}
    ];
    public readonly COURSE_TYPE: { key: string, text: string }[] = [
        {key: 'regular', text: 'Regular'},
        {key: 'correspondence', text: 'Correspondence'}
    ];
    // endregion

    // region Private properties to hold INPUT property received
    private _selectedEmployeeId: number;
    private _employeeEducationItem: EmployeeEducationModel;
    private _isShowForm: boolean = false;
    private _isValidateEducationItem: boolean = false;
    // endregion

    // region Event emitter property that emits an event to parent education component when education item created or updated successfully
    private _isEditMode: EventEmitter <boolean> = new EventEmitter<boolean>();
    private _isEducationFormValid: EventEmitter <boolean> = new EventEmitter<boolean>();
    // endregion

    // region Private properties. Becomes public with getter and setters
    private _employeeEducationForm: FormGroup;
    private _isParentFormSubmitted: boolean = false;
    private _message: string;
    private _isShowErrorMessage: boolean = false;
    // endregion


    // region GETTERS/SETTERS for all input properties
    get selectedEmployeeId(): number {
        return this._selectedEmployeeId;
    }

    @Input() set selectedEmployeeId(value: number) {
        this._selectedEmployeeId = value;
    }

    get employeeEducationItem(): EmployeeEducationModel {
        return this._employeeEducationItem;
    }

    @Input() set employeeEducationItem(value: EmployeeEducationModel) {
        this._employeeEducationItem = value;
    }

    get isShowForm(): boolean {
        return this._isShowForm;
    }

    @Input() set isShowForm(value: boolean) {
        this._isShowForm = value;
    }


    get isValidateEducationItem(): boolean {
        return this._isValidateEducationItem;
    }

    @Input() set isValidateEducationItem(value: boolean) {
        this._isValidateEducationItem = value;
        this._validateEducationForm();
    }

// endregion

    // region GETTERS for all OUTPUT properties
    @Output() get isEducationFormValid(): EventEmitter<boolean> {
        return this._isEducationFormValid;
    }

    @Output() get isEditMode(): EventEmitter<boolean> {
        return this._isEditMode;
    }

// endregion

    // region GETTERS/SETTERS for all public properties
    get employeeEducationForm(): FormGroup {
        return this._employeeEducationForm;
    }

    set employeeEducationForm(value: FormGroup) {
        this._employeeEducationForm = value;
    }

    get isParentFormSubmitted(): boolean {
        return this._isParentFormSubmitted;
    }

    set isParentFormSubmitted(value: boolean) {
        this._isParentFormSubmitted = value;
    }

    get message(): string {
        return this._message;
    }

    set message(value: string) {
        this._message = value;
    }

    get isShowErrorMessage(): boolean {
        return this._isShowErrorMessage;
    }

    set isShowErrorMessage(value: boolean) {
        this._isShowErrorMessage = value;
    }

    // endregion

    /**
     * Constructor method for EmployeeEducationComponent
     * @param  _sysMan                 SysManService           Dependency injection for SysManService
     * @param _fb                      FormBuilder             Dependency injection for FormBuilder
     * @param  _router                 Router                  Dependency injection for Router
     * @param _educationModel         EmployeeEducationModel   Dependency injection for EmployeeEducationModel
     */
    constructor(private _sysMan: SysManService,
                private _fb: FormBuilder,
                private _router: Router,
                private _educationModel: EmployeeEducationModel) {
        this._sysMan.logger.debug('START constructor()', this.constructor.name);
        this._sysMan.logger.debug('END constructor()', this.constructor.name);
    }

    /**
     *  Lifecycle hook called after construction for initialization tasks
     */
    ngOnInit(): void {
        this._sysMan.logger.debug('START ngOnInit()', this.constructor.name);
        this.employeeEducationForm = this._fb.group({});
        this._sysMan.logger.debug('END ngOnInit()', this.constructor.name);
    }


    private _validateEducationForm() {
        this._sysMan.logger.debug('START _validateEducationForm()', this.constructor.name);
        if (this.employeeEducationForm) {
            this.isParentFormSubmitted = true;
            if (this.employeeEducationForm.valid) {
                this.isEducationFormValid.emit(true);
            } else {
                this.isEducationFormValid.emit(false);
            }
        } else {
            this.isEducationFormValid.emit(false);
        }
        this._sysMan.logger.debug('END _validateEducationForm()', this.constructor.name);
    }
    /**
     * Reset form data
     */
    public resetForm() {
        this._sysMan.logger.debug('START resetForm()', this.constructor.name);
        this.isShowForm = false;  // close the form
        this.isParentFormSubmitted = false;   // set isFormSubmitted to false
        this.employeeEducationForm.reset(this.employeeEducationItem);  // reset the form
        this._sysMan.logger.debug('END resetForm()', this.constructor.name);
    }

    /**
     * Method to display error message in respective fields
     * @param key
     */
    public showMessages(key) {
        if (this.employeeEducationItem.messages && key in this.employeeEducationItem.messages) {
            return this.employeeEducationItem.messages[key];
        }
    }

    public prepareEmployeeEducation(fieldType: string) {
        this.employeeEducationItem.idEmployee = this.selectedEmployeeId;
        switch (fieldType) {
            case 'level':
                this.employeeEducationItem.level = this.employeeEducationForm.controls['level'].value;
                break;
            case 'stream':
                this.employeeEducationItem.stream = this.employeeEducationForm.controls['stream'].value;
                break;
            case 'institute':
                this.employeeEducationItem.institute = this.employeeEducationForm.controls['institute'].value;
                break;
            case 'passedYear':
                this.employeeEducationItem.passedYear = this.employeeEducationForm.controls['passedYear'].value;
                break;
            case 'finalScore':
                this.employeeEducationItem.finalScore = this.employeeEducationForm.controls['finalScore'].value;
                break;
            case 'finalScoreIn':
                this.employeeEducationItem.finalScoreIn = this.employeeEducationForm.controls['finalScoreIn'].value;
                break;
            case 'courseType':
                this.employeeEducationItem.courseType = this.employeeEducationForm.controls['courseType'].value;
                break;
            default:
                break;
        }
    }

    public changeEducationItemMode(mode: string) {
        this._sysMan.logger.debug('START changeEducationItemMode()', this.constructor.name);
            if(mode == 'edit') {
                this.isShowForm = true;
                this.isEditMode.emit(true);
            } else {
                this.isEditMode.emit(true);
            }
        this._sysMan.logger.debug('END changeEducationItemMode()', this.constructor.name);

    }
}
