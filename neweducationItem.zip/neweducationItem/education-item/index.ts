export * from './employee-education-item.component';
